WAdata=[
    {
        "name":"Web developer",
        "img":"img/pp10.jfif",
        "last":"+91 7708544891: S tq",
        "time":"Thursday",
        
    },
    {
        "name":"Zulfi iipe",
        "img":"img/pp1.jfif",
        "last":"ha ha",
        "time":"Thursday",
        "noti":"0"
        
    },
    {
        "name":"venky",
        "img":"img/pp2.jfif",
        "last":"html",
        "time":"Thursday",
        "noti":"5"
    },
    {
        "name":"Sathyam ji",
        "img":"img/pp3.jfif",
        "last":"all the best",
        "time":"wednesday",
        "noti":"0"
    },
    {
        "name":"Karthi Ece",
        "img":"img/pp4.jfif",
        "last":"pubg vaa",
        "time":"wednesday",
        "noti":"1"
    },
    {
        "name":"MMs",
        "img":"img/pp5.jfif",
        "last":"Raja annan: going to chennai",
        "time":"Tuesday",
        "noti":"2"
    },
    {
        "name":"Akshay sunil kumar iipe",
        "img":"img/pp11.jfif",
        "last":"kerala va",
        "time":"Tuesday",
        "noti":"0"
    },
    {
        "name":"Aadhavan iipe",
        "img":"img/pp7.jfif",
        "last":"epdi eruka",
        "time":"Tuesday",
        "noti":"0"
    },
    {
        "name":"Rajesh kanna Ece",
        "img":"img/pp8.jfif",
        "last":"goms",
        "time":"Monday",
        "noti":"0"
    },
    {
        "name":"Naveen",
        "img":"img/pp1.jfif",
        "last":"lemon tea",
        "time":"Monday",
        "noti":"0"
    },
    {
        "name":"Amma",
        "img":"img/pp10.jfif",
        "last":"hlo",
        "time":"Sunday",
        "noti":"0"
    }
  
]